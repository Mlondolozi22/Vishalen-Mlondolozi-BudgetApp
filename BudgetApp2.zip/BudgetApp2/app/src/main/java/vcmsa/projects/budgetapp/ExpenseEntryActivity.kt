package vcmsa.projects.budgetapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class ExpenseEntryActivity : AppCompatActivity() {
    private lateinit var descriptionEditText: EditText
    private lateinit var dateEditText: EditText
    private lateinit var startTimeEditText: EditText
    private lateinit var endTimeEditText: EditText
    private lateinit var categoryEditText: EditText
    private lateinit var addPhotoButton: Button
    private lateinit var saveButton: Button
    private lateinit var photoPreview: ImageView
    private var photoUri: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_expense_entry)

        // Bind UI elements
        descriptionEditText = findViewById(R.id.descriptionEditText)
        dateEditText = findViewById(R.id.dateEditText)
        startTimeEditText = findViewById(R.id.startTimeEditText)
        endTimeEditText = findViewById(R.id.endTimeEditText)
        categoryEditText = findViewById(R.id.categoryEditText)
        addPhotoButton = findViewById(R.id.addPhotoButton)
        saveButton = findViewById(R.id.saveButton)
        photoPreview = findViewById(R.id.photoPreview)

        // Photo button logic
        addPhotoButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, 100)
        }

        // Save expense logic
        saveButton.setOnClickListener {
            val description = descriptionEditText.text.toString().trim()
            val date = dateEditText.text.toString().trim()
            val startTime = startTimeEditText.text.toString().trim()
            val endTime = endTimeEditText.text.toString().trim()
            val category = categoryEditText.text.toString().trim()

            if (description.isNotEmpty() && date.isNotEmpty() && startTime.isNotEmpty() && endTime.isNotEmpty() && category.isNotEmpty()) {
                val expense = Expense(
                    date = date,
                    startTime = startTime,
                    endTime = endTime,
                    description = description,
                    categoryId = category,
                    photoUri = photoUri
                )

                // Save to Room database
                lifecycleScope.launch {
                    AppDatabase.getInstance(applicationContext).expenseDao().insert(expense)
                    runOnUiThread {
                        Toast.makeText(this@ExpenseEntryActivity, "Expense saved!", Toast.LENGTH_SHORT).show()
                        finish() // Close activity
                    }
                }

            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            photoUri = data?.data.toString()
            photoPreview.setImageURI(Uri.parse(photoUri))
            Toast.makeText(this, "Photo added!", Toast.LENGTH_SHORT).show()
        }
    }
}
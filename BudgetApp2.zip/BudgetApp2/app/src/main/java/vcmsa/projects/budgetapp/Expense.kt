package vcmsa.projects.budgetapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val categoryId: String,
    val photoUri: String? = null
)

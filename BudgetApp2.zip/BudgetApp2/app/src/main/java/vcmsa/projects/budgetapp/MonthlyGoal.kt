package vcmsa.projects.budgetapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_goals")
data class MonthlyGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val month: String, // Format: "2025-05"
    val minGoal: Double,
    val maxGoal: Double
)
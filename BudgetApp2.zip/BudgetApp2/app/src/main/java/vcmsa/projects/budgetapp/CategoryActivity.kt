package vcmsa.projects.budgetapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class CategoryActivity : AppCompatActivity() {
    private lateinit var categoryNameEditText: EditText
    private lateinit var createCategoryButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_category)

        categoryNameEditText = findViewById(R.id.categoryNameEditText)
        createCategoryButton = findViewById(R.id.createCategoryButton)

        createCategoryButton.setOnClickListener {
            val categoryName = categoryNameEditText.text.toString()

            if (categoryName.isNotEmpty()) {
                // Save the category to the database or a local data structure
                Toast.makeText(this, "Category '$categoryName' created", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
package vcmsa.projects.budgetapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BudgetGoalActivity : AppCompatActivity() {
    private lateinit var monthEditText: EditText
    private lateinit var minGoalEditText: EditText
    private lateinit var maxGoalEditText: EditText
    private lateinit var saveGoalButton: Button
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_goal)

        db = AppDatabase.getInstance(this)
        monthEditText = findViewById(R.id.monthEditText)
        minGoalEditText = findViewById(R.id.minGoalEditText)
        maxGoalEditText = findViewById(R.id.maxGoalEditText)
        saveGoalButton = findViewById(R.id.saveGoalButton)

        saveGoalButton.setOnClickListener {
            val month = monthEditText.text.toString()
            val min = minGoalEditText.text.toString().toDoubleOrNull()
            val max = maxGoalEditText.text.toString().toDoubleOrNull()

            if (month.isNotEmpty() && min != null && max != null) {
                val goal = MonthlyGoal(month = month, minGoal = min, maxGoal = max)

                CoroutineScope(Dispatchers.IO).launch {
                    db.monthlyGoalDao().insert(goal)
                    runOnUiThread {
                        Toast.makeText(this@BudgetGoalActivity, "Goal Saved", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            } else {
                Toast.makeText(this, "Please enter valid values", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
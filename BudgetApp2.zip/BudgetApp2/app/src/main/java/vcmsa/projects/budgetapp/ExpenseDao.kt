package vcmsa.projects.budgetapp

import androidx.room.*

@Dao
interface ExpenseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense)

    @Query("SELECT * FROM expenses")
    suspend fun getAll(): List<Expense>
}